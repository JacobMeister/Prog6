﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using Prog6_EindOpdracht.WCF.Data;
using Prog6_EindOpdracht.WCF.Factories;

namespace Prog6_EindOpdracht.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "TamagotchiService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select TamagotchiService.svc or TamagotchiService.svc.cs at the Solution Explorer and start debugging.
    public class TamagotchiService : ITamagotchiService
    {
        public TamagotchiService()
        {
            
        }

        public List<Tamagotchi> GetTamagotchis()
        {
            using (var context = new Prog6_Entities())
            {
                var tamagotchis = context.Tamagotchi.ToList();
                return tamagotchis.ToList();
            }
        }

        public void CreateTamagotchi(string name)
        {
            using (var context = new Prog6_Entities())
            {
                context.Tamagotchi.Add(TamagotchiFactory.Create(name));
                context.SaveChanges();              
            }
        }

        public string WorkingService()
        {
            return "The Service is working!";
        }

        public bool WorkingDbContext()
        {
            int ba = 1;
            using (var context = new Prog6_Entities())
            {         
                return context.Tamagotchi.Count() == 2;
            }
        }
    }
}
