﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;
using Prog6_EindOpdracht.WCF.Data;


namespace Prog6_EindOpdracht.WCF
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "ITamagotchiService" in both code and config file together.
    [ServiceContract]
    public interface ITamagotchiService
    {

        [OperationContract]
        List<Tamagotchi> GetTamagotchis();

        [OperationContract]
        void CreateTamagotchi(string name);

        // TODO: Add your service operations here
        [OperationContract]
        String WorkingService();

        [OperationContract]
        bool WorkingDbContext();
    }   
}
